package com.demeter.gestaoagro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoagroApplicationTests {

	@Test
	void contextLoads() {
	}

}
