package com.demeter.gestaoagro.exception;

public class RegistroNaoPodeSerAtualizadoException extends java.lang.RuntimeException {

    public RegistroNaoPodeSerAtualizadoException(String message) {
        super(message);
    }
}

//exception tbmd