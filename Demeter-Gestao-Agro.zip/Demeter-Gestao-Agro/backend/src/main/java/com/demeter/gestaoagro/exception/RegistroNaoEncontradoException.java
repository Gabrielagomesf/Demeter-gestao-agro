package com.demeter.gestaoagro.exception;

public class RegistroNaoEncontradoException extends RuntimeException {

    public RegistroNaoEncontradoException(String message) {
        super(message);
    }
}

//pra lançar as exceptionN